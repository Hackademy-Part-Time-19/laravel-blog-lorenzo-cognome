<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <a href="/articoli"></a>
    <a href="/sito-improvvisato"></a>
</head>
<body>
    <h1>titolo 3</h1>
    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Corrupti eum quam ea sunt iure optio adipisci vitae minima ipsam ducimus suscipit, commodi aut maiores accusantium cumque quidem qui libero eos?</p>
</body>
</html>